import "./App.css";
import SuperDocPdfViewer from "./SuperDocPdfViewer";

function App() {
  return <SuperDocPdfViewer />;
}

export default App;
