import { SuperDoc } from "@harbour-enterprises/superdoc";
import "@harbour-enterprises/superdoc/style.css";
import { useEffect, useRef, useState } from "react";

type SearchResult = { from: number; to: number; text?: string };

// Default price strings to search for
const DEFAULT_PRICES = [
  "50.000.000",
  "1.200.000",
  "8.500.000",
  "35.000.000",
  "93.500.000",
  "năm mươi triệu đồng",
  "1,2 triệu",
];

export default function SuperDocPdfViewer() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const superdocRef = useRef<SuperDoc | null>(null);

  const [pricesText, setPricesText] = useState<string>(() =>
    DEFAULT_PRICES.join("\n")
  );
  const [reloadKey, setReloadKey] = useState(0);
  const [documentPath, setDocumentPath] = useState<string>("/contract.pdf");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;

    setIsLoading(true);

    const sdoc = new SuperDoc({
      selector: containerRef.current as any,
      document: { type: "pdf", url: documentPath },
      format: "pdf",
      documentMode: "viewing",
      user: { name: "demo", email: "demo@local" },
      documents: [],
      pagination: true,
      onReady: (event) => {
        console.log("SuperDoc PDF viewer is ready", event);
        setIsLoading(false);
      },
      onEditorCreate: (event) => {
        console.log("PDF Editor is created", event);
      },
      onContentError: (error) => {
        console.log("PDF Content error occurred", error);
        setIsLoading(false);
      },
      onPdfDocumentReady: () => {
        console.log("PDF document is ready");
        setIsLoading(false);
      },
    });

    superdocRef.current = sdoc;

    return () => {
      superdocRef.current?.destroy?.();
      superdocRef.current = null;
      if (containerRef.current) {
        containerRef.current.innerHTML = "";
      }
    };
  }, [reloadKey, documentPath]);

  // Parse price strings from textarea (one per line)
  const parsePrices = (): string[] => {
    return pricesText
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
  };

  const handleHighlight = () => {
    const sdoc = superdocRef.current;
    if (!sdoc) return;

    const editor = sdoc.activeEditor;
    if (!editor) return;

    const prices = parsePrices();
    const allMatches: SearchResult[] = prices.flatMap((price) => {
      const results = sdoc.search(price) as SearchResult[];
      return results || [];
    });

    if (!allMatches.length) {
      console.log("No matches found for highlighting");
      return;
    }

    const uniq = new Map<string, SearchResult>();
    for (const m of allMatches) uniq.set(`${m.from}-${m.to}`, m);
    const matches = Array.from(uniq.values());

    console.log(`Found ${matches.length} matches to highlight`);

    matches.forEach((match) => {
      try {
        sdoc.goToSearchResult(match);
        if (editor.commands?.setHighlight) {
          editor.commands.setHighlight({ color: "#ffff00" }); // Yellow highlight
        } else if (editor.commands?.toggleHighlight) {
          editor.commands.toggleHighlight({ color: "#ffff00" });
        } else if (editor.commands?.setMark) {
          editor.commands.setMark("highlight", { color: "#ffff00" });
        }
      } catch (error) {
        console.error("Error highlighting match:", error);
      }
    });
  };

  const handleClearHighlights = () => {
    const sdoc = superdocRef.current;
    if (!sdoc) return;

    const editor = sdoc.activeEditor;
    if (!editor) return;

    try {
      // Try to clear all highlights
      if (editor.commands?.unsetHighlight) {
        editor.commands.unsetHighlight();
      } else if (editor.commands?.toggleHighlight) {
        editor.commands.toggleHighlight({ color: "#ffff00" });
      } else if (editor.commands?.unsetMark) {
        editor.commands.unsetMark("highlight");
      }
      console.log("Highlights cleared");
    } catch (error) {
      console.error("Error clearing highlights:", error);
    }
  };

  return (
    <div className="p-4 space-y-12">
      <section>
        <h2>PDF Viewer Controls</h2>
        <div style={{ display: "grid", gap: 12, maxWidth: 680 }}>
          <label>
            PDF File:
            <select
              value={documentPath}
              onChange={(e) => {
                setDocumentPath(e.target.value);
                setReloadKey((k) => k + 1);
              }}
              style={{ width: "100%", padding: 8, marginTop: 6 }}
            >
              <option value="/contract.pdf">Contract.pdf</option>
              <option value="/Contract.pdf">Contract.pdf (Capital C)</option>
            </select>
          </label>

          <label>
            Price strings to highlight (one per line):
            <textarea
              rows={6}
              value={pricesText}
              onChange={(e) => setPricesText(e.target.value)}
              placeholder="Enter price strings to search for..."
              style={{
                width: "100%",
                padding: 8,
                marginTop: 6,
                fontFamily: "monospace",
              }}
            />
          </label>

          <div
            style={{
              display: "flex",
              gap: 8,
              flexWrap: "wrap",
              marginTop: 16,
              marginBottom: 16,
            }}
          >
            <button
              onClick={handleHighlight}
              disabled={isLoading}
              style={{ backgroundColor: "#ffff00", color: "#000" }}
            >
              Highlight prices
            </button>
            <button
              onClick={handleClearHighlights}
              disabled={isLoading}
              style={{ backgroundColor: "#f0f0f0", color: "#000" }}
            >
              Clear highlights
            </button>
            <button
              onClick={() => setReloadKey((k) => k + 1)}
              disabled={isLoading}
              style={{ backgroundColor: "#e6f3ff", color: "#000" }}
            >
              Reload PDF
            </button>
          </div>

          {isLoading && (
            <div style={{ textAlign: "center", padding: 20 }}>
              <div>Loading PDF...</div>
            </div>
          )}
        </div>
      </section>

      <section>
        <div
          ref={containerRef}
          style={{
            height: 720,
            overflow: "auto",
            margin: "auto",
            border: "1px solid #ddd",
            borderRadius: 8,
            width: "fit-content",
            backgroundColor: isLoading ? "#f9f9f9" : "white",
          }}
        />
      </section>
    </div>
  );
}
